"""
ProfIAs - Plataforma de Geração de Materiais Pedagógicos com IA

Este é o arquivo principal da aplicação FastAPI que orquestra toda a plataforma.
A aplicação é estruturada em camadas para garantir modularidade e manutenibilidade.

Autor: Equipe ProfIAs - IFRS Campus Porto Alegre
"""

from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from contextlib import asynccontextmanager
import uvicorn
import os
from pathlib import Path

# Importações dos módulos da aplicação
from app.database import init_db
from app.routers import auth, materials, ai_generation, export, collaboration
from app.core.config import settings

# Configuração de segurança para autenticação JWT
security = HTTPBearer()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Gerencia o ciclo de vida da aplicação.
    Inicializa o banco de dados na startup e limpa recursos no shutdown.
    """
    # Startup: Inicializa o banco de dados
    await init_db()
    print("🚀 ProfIAs iniciado com sucesso!")
    yield
    # Shutdown: Aqui podemos adicionar limpeza de recursos se necessário
    print("👋 ProfIAs finalizado")

# Criação da instância principal do FastAPI
app = FastAPI(
    title="ProfIAs - Plataforma Pedagógica com IA",
    description="Sistema para geração de materiais didáticos utilizando Inteligência Artificial",
    version="1.0.0",
    docs_url="/docs",  # Documentação automática da API
    redoc_url="/redoc",  # Documentação alternativa
    lifespan=lifespan
)

# Configuração de CORS para permitir requisições do frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especificar domínios exatos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Montagem de arquivos estáticos (CSS, JS, imagens)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Registro dos roteadores da API
# Cada roteador gerencia um conjunto específico de funcionalidades
app.include_router(auth.router, prefix="/api/auth", tags=["Autenticação"])
app.include_router(materials.router, prefix="/api/materials", tags=["Materiais"])
app.include_router(ai_generation.router, prefix="/api/ai", tags=["Geração IA"])
app.include_router(export.router, prefix="/api/export", tags=["Exportação"])
app.include_router(collaboration.router, prefix="/api/collaboration", tags=["Colaboração"])

@app.get("/", response_class=HTMLResponse)
async def read_root():
    """
    Rota principal que serve a página inicial da aplicação.
    Retorna o arquivo HTML principal com toda a interface do usuário.
    """
    return FileResponse("static/index.html")

@app.get("/health")
async def health_check():
    """
    Endpoint de verificação de saúde da aplicação.
    Útil para monitoramento e verificação se o serviço está funcionando.
    """
    return {
        "status": "healthy",
        "message": "ProfIAs está funcionando corretamente",
        "version": "1.0.0"
    }

@app.exception_handler(404)
async def not_found_handler(request: Request, exc: HTTPException):
    """
    Manipulador personalizado para erros 404.
    Redireciona para a página principal em caso de rota não encontrada.
    """
    return FileResponse("static/index.html")

if __name__ == "__main__":
    # Configuração para execução direta do arquivo
    # Em produção, usar um servidor ASGI como Gunicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,  # Recarrega automaticamente em desenvolvimento
        log_level="info"
    )