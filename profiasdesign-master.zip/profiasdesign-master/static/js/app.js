/**
 * ProfIAs - Aplicação Frontend Principal
 * 
 * Este arquivo gerencia toda a interatividade da interface do usuário,
 * incluindo autenticação, navegação, modais e comunicação com a API.
 * 
 * Autor: Equipe ProfIAs - IFRS Campus Porto Alegre
 */

// === CONFIGURAÇÕES GLOBAIS ===
const API_BASE_URL = '/api';
let currentUser = null;
let authToken = null;

// === UTILITÁRIOS ===

/**
 * Faz requisições HTTP para a API com tratamento de erros
 * @param {string} endpoint - Endpoint da API
 * @param {Object} options - Opções da requisição (método, body, etc.)
 * @returns {Promise} Resposta da API
 */
async function apiRequest(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    // Configurações padrão da requisição
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        },
    };
    
    // Adiciona token de autenticação se disponível
    if (authToken) {
        defaultOptions.headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    // Mescla opções padrão com as fornecidas
    const finalOptions = {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...options.headers,
        },
    };
    
    try {
        const response = await fetch(url, finalOptions);
        
        // Verifica se a resposta foi bem-sucedida
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.detail || `Erro HTTP: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Erro na requisição:', error);
        throw error;
    }
}

/**
 * Exibe notificações para o usuário
 * @param {string} message - Mensagem a ser exibida
 * @param {string} type - Tipo da notificação (success, error, info)
 */
function showNotification(message, type = 'info') {
    // Remove notificação anterior se existir
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Cria nova notificação
    const notification = document.createElement('div');
    notification.className = `notification fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm transform transition-all duration-300 translate-x-full`;
    
    // Define cores baseadas no tipo
    const typeClasses = {
        success: 'bg-green-500 text-white',
        error: 'bg-red-500 text-white',
        info: 'bg-blue-500 text-white',
        warning: 'bg-yellow-500 text-black'
    };
    
    notification.className += ` ${typeClasses[type] || typeClasses.info}`;
    notification.innerHTML = `
        <div class="flex items-center justify-between">
            <span>${message}</span>
            <button class="ml-4 text-current opacity-70 hover:opacity-100" onclick="this.parentElement.parentElement.remove()">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Anima a entrada
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Remove automaticamente após 5 segundos
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

/**
 * Gerencia o armazenamento local do token de autenticação
 */
const TokenManager = {
    save(token) {
        localStorage.setItem('profias_token', token);
        authToken = token;
    },
    
    get() {
        const token = localStorage.getItem('profias_token');
        if (token) {
            authToken = token;
        }
        return token;
    },
    
    remove() {
        localStorage.removeItem('profias_token');
        authToken = null;
    }
};

// === GERENCIAMENTO DE AUTENTICAÇÃO ===

/**
 * Classe responsável por gerenciar autenticação de usuários
 */
class AuthManager {
    constructor() {
        this.initializeAuth();
    }
    
    /**
     * Inicializa o sistema de autenticação verificando token salvo
     */
    async initializeAuth() {
        const savedToken = TokenManager.get();
        if (savedToken) {
            try {
                // Verifica se o token ainda é válido
                const userData = await apiRequest('/auth/me');
                this.setCurrentUser(userData);
                this.updateUIForAuthenticatedUser();
            } catch (error) {
                // Token inválido, remove do storage
                TokenManager.remove();
                this.updateUIForUnauthenticatedUser();
            }
        } else {
            this.updateUIForUnauthenticatedUser();
        }
    }
    
    /**
     * Realiza login do usuário
     * @param {string} email - Email do usuário
     * @param {string} password - Senha do usuário
     */
    async login(email, password) {
        try {
            const response = await apiRequest('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });
            
            // Salva o token e obtém dados do usuário
            TokenManager.save(response.access_token);
            const userData = await apiRequest('/auth/me');
            
            this.setCurrentUser(userData);
            this.updateUIForAuthenticatedUser();
            
            showNotification('Login realizado com sucesso!', 'success');
            this.closeModals();
            
        } catch (error) {
            showNotification(error.message || 'Erro ao fazer login', 'error');
            throw error;
        }
    }
    
    /**
     * Realiza cadastro de novo usuário
     * @param {Object} userData - Dados do usuário para cadastro
     */
    async register(userData) {
        try {
            await apiRequest('/auth/register', {
                method: 'POST',
                body: JSON.stringify(userData)
            });
            
            showNotification('Conta criada com sucesso! Faça login para continuar.', 'success');
            this.showLoginModal();
            
        } catch (error) {
            showNotification(error.message || 'Erro ao criar conta', 'error');
            throw error;
        }
    }
    
    /**
     * Realiza logout do usuário
     */
    logout() {
        TokenManager.remove();
        currentUser = null;
        this.updateUIForUnauthenticatedUser();
        showNotification('Logout realizado com sucesso!', 'info');
        
        // Redireciona para a página inicial se estiver em área restrita
        if (window.location.hash.includes('dashboard') || window.location.hash.includes('materiais')) {
            window.location.hash = '#inicio';
        }
    }
    
    /**
     * Define o usuário atual
     * @param {Object} userData - Dados do usuário
     */
    setCurrentUser(userData) {
        currentUser = userData;
    }
    
    /**
     * Atualiza a interface para usuário autenticado
     */
    updateUIForAuthenticatedUser() {
        const authButtons = document.getElementById('auth-buttons');
        const userMenu = document.getElementById('user-menu');
        const userInitials = document.getElementById('user-initials');
        const userName = document.getElementById('user-name');
        
        if (authButtons) authButtons.classList.add('hidden');
        if (userMenu) userMenu.classList.remove('hidden');
        
        if (currentUser && userInitials && userName) {
            // Extrai iniciais do nome
            const initials = currentUser.full_name
                .split(' ')
                .map(name => name.charAt(0))
                .join('')
                .substring(0, 2)
                .toUpperCase();
            
            userInitials.textContent = initials;
            userName.textContent = currentUser.full_name.split(' ')[0]; // Primeiro nome
        }
    }
    
    /**
     * Atualiza a interface para usuário não autenticado
     */
    updateUIForUnauthenticatedUser() {
        const authButtons = document.getElementById('auth-buttons');
        const userMenu = document.getElementById('user-menu');
        
        if (authButtons) authButtons.classList.remove('hidden');
        if (userMenu) userMenu.classList.add('hidden');
    }
    
    /**
     * Exibe modal de login
     */
    showLoginModal() {
        const loginModal = document.getElementById('login-modal');
        const registerModal = document.getElementById('register-modal');
        
        if (registerModal) registerModal.classList.add('hidden');
        if (loginModal) loginModal.classList.remove('hidden');
    }
    
    /**
     * Exibe modal de cadastro
     */
    showRegisterModal() {
        const loginModal = document.getElementById('login-modal');
        const registerModal = document.getElementById('register-modal');
        
        if (loginModal) loginModal.classList.add('hidden');
        if (registerModal) registerModal.classList.remove('hidden');
    }
    
    /**
     * Fecha todos os modais
     */
    closeModals() {
        const modals = document.querySelectorAll('[id$="-modal"]');
        modals.forEach(modal => modal.classList.add('hidden'));
    }
}

// === GERENCIAMENTO DE NAVEGAÇÃO ===

/**
 * Classe responsável por gerenciar navegação e roteamento
 */
class NavigationManager {
    constructor() {
        this.initializeNavigation();
    }
    
    /**
     * Inicializa o sistema de navegação
     */
    initializeNavigation() {
        // Navegação suave para âncoras
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
        
        // Menu mobile
        this.initializeMobileMenu();
        
        // Dropdown do usuário
        this.initializeUserDropdown();
    }
    
    /**
     * Inicializa o menu mobile
     */
    initializeMobileMenu() {
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
            
            // Fecha menu ao clicar em links
            mobileMenu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.add('hidden');
                });
            });
        }
    }
    
    /**
     * Inicializa o dropdown do usuário
     */
    initializeUserDropdown() {
        const userMenuBtn = document.getElementById('user-menu-btn');
        const userDropdown = document.getElementById('user-dropdown');
        
        if (userMenuBtn && userDropdown) {
            userMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                userDropdown.classList.toggle('hidden');
            });
            
            // Fecha dropdown ao clicar fora
            document.addEventListener('click', () => {
                userDropdown.classList.add('hidden');
            });
            
            // Previne fechamento ao clicar dentro do dropdown
            userDropdown.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
    }
}

// === GERENCIAMENTO DE FORMULÁRIOS ===

/**
 * Classe responsável por gerenciar formulários da aplicação
 */
class FormManager {
    constructor() {
        this.initializeForms();
    }
    
    /**
     * Inicializa todos os formulários
     */
    initializeForms() {
        this.initializeLoginForm();
        this.initializeRegisterForm();
        this.initializeContactForm();
    }
    
    /**
     * Inicializa o formulário de login
     */
    initializeLoginForm() {
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(loginForm);
                const email = formData.get('email');
                const password = formData.get('password');
                
                // Desabilita botão durante o processo
                const submitBtn = loginForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Entrando...';
                
                try {
                    await authManager.login(email, password);
                } catch (error) {
                    // Erro já tratado no AuthManager
                } finally {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
        }
    }
    
    /**
     * Inicializa o formulário de cadastro
     */
    initializeRegisterForm() {
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(registerForm);
                const password = formData.get('password');
                const confirmPassword = formData.get('confirm_password');
                
                // Valida confirmação de senha
                if (password !== confirmPassword) {
                    showNotification('As senhas não coincidem', 'error');
                    return;
                }
                
                // Prepara dados para envio
                const userData = {
                    full_name: formData.get('full_name'),
                    email: formData.get('email'),
                    institution: formData.get('institution'),
                    department: formData.get('department'),
                    password: password
                };
                
                // Desabilita botão durante o processo
                const submitBtn = registerForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Criando conta...';
                
                try {
                    await authManager.register(userData);
                    registerForm.reset();
                } catch (error) {
                    // Erro já tratado no AuthManager
                } finally {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
        }
    }
    
    /**
     * Inicializa o formulário de contato
     */
    initializeContactForm() {
        const contactForm = document.getElementById('contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                // Simula envio de email (em produção, implementar backend)
                const submitBtn = contactForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Enviando...';
                
                // Simula delay de envio
                setTimeout(() => {
                    showNotification('Mensagem enviada com sucesso! Entraremos em contato em breve.', 'success');
                    contactForm.reset();
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }, 2000);
            });
        }
    }
}

// === GERENCIAMENTO DE MODAIS ===

/**
 * Classe responsável por gerenciar modais da aplicação
 */
class ModalManager {
    constructor() {
        this.initializeModals();
    }
    
    /**
     * Inicializa todos os modais
     */
    initializeModals() {
        this.initializeModalTriggers();
        this.initializeModalClosers();
        this.initializeModalSwitchers();
    }
    
    /**
     * Inicializa botões que abrem modais
     */
    initializeModalTriggers() {
        // Botões de login
        const loginBtns = [
            document.getElementById('login-btn'),
            document.getElementById('mobile-login-btn'),
            document.getElementById('hero-start-btn')
        ];
        
        loginBtns.forEach(btn => {
            if (btn) {
                btn.addEventListener('click', () => {
                    if (currentUser) {
                        // Se já estiver logado, redireciona para dashboard
                        window.location.hash = '#dashboard';
                    } else {
                        authManager.showLoginModal();
                    }
                });
            }
        });
        
        // Botões de cadastro
        const registerBtns = [
            document.getElementById('register-btn'),
            document.getElementById('mobile-register-btn')
        ];
        
        registerBtns.forEach(btn => {
            if (btn) {
                btn.addEventListener('click', () => {
                    authManager.showRegisterModal();
                });
            }
        });
    }
    
    /**
     * Inicializa botões que fecham modais
     */
    initializeModalClosers() {
        // Botões de fechar
        const closeButtons = [
            document.getElementById('close-login-modal'),
            document.getElementById('close-register-modal')
        ];
        
        closeButtons.forEach(btn => {
            if (btn) {
                btn.addEventListener('click', () => {
                    authManager.closeModals();
                });
            }
        });
        
        // Fechar ao clicar no backdrop
        document.querySelectorAll('[id$="-modal"]').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    authManager.closeModals();
                }
            });
        });
        
        // Fechar com ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                authManager.closeModals();
            }
        });
    }
    
    /**
     * Inicializa botões que alternam entre modais
     */
    initializeModalSwitchers() {
        const switchToRegister = document.getElementById('switch-to-register');
        const switchToLogin = document.getElementById('switch-to-login');
        
        if (switchToRegister) {
            switchToRegister.addEventListener('click', () => {
                authManager.showRegisterModal();
            });
        }
        
        if (switchToLogin) {
            switchToLogin.addEventListener('click', () => {
                authManager.showLoginModal();
            });
        }
    }
}

// === EFEITOS VISUAIS E ANIMAÇÕES ===

/**
 * Classe responsável por efeitos visuais e animações
 */
class VisualEffectsManager {
    constructor() {
        this.initializeEffects();
    }
    
    /**
     * Inicializa todos os efeitos visuais
     */
    initializeEffects() {
        this.initializeScrollEffects();
        this.initializeHoverEffects();
        this.initializeLoadingAnimations();
    }
    
    /**
     * Inicializa efeitos baseados em scroll
     */
    initializeScrollEffects() {
        // Observador de interseção para animações de entrada
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, observerOptions);
        
        // Observa elementos que devem animar na entrada
        document.querySelectorAll('.card-glass, .grid > div, section > div').forEach(el => {
            observer.observe(el);
        });
        
        // Efeito parallax sutil no hero
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const heroSection = document.getElementById('inicio');
            
            if (heroSection) {
                const rate = scrolled * -0.5;
                heroSection.style.transform = `translateY(${rate}px)`;
            }
        });
    }
    
    /**
     * Inicializa efeitos de hover
     */
    initializeHoverEffects() {
        // Efeito de ondulação em botões
        document.querySelectorAll('.btn-primary, button').forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
    }
    
    /**
     * Inicializa animações de carregamento
     */
    initializeLoadingAnimations() {
        // Adiciona classe de carregamento inicial
        document.body.classList.add('loading');
        
        // Remove após carregamento completo
        window.addEventListener('load', () => {
            setTimeout(() => {
                document.body.classList.remove('loading');
                document.body.classList.add('loaded');
            }, 500);
        });
    }
}

// === INICIALIZAÇÃO DA APLICAÇÃO ===

// Instâncias globais dos gerenciadores
let authManager;
let navigationManager;
let formManager;
let modalManager;
let visualEffectsManager;

/**
 * Inicializa toda a aplicação
 */
function initializeApp() {
    // Inicializa gerenciadores na ordem correta
    authManager = new AuthManager();
    navigationManager = new NavigationManager();
    formManager = new FormManager();
    modalManager = new ModalManager();
    visualEffectsManager = new VisualEffectsManager();
    
    // Configura logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            authManager.logout();
        });
    }
    
    // Configura botão de demonstração
    const demoBtn = document.getElementById('hero-demo-btn');
    if (demoBtn) {
        demoBtn.addEventListener('click', () => {
            // Scroll suave para seção de recursos
            document.getElementById('recursos').scrollIntoView({
                behavior: 'smooth'
            });
        });
    }
    
    console.log('🚀 ProfIAs inicializado com sucesso!');
}

// === ESTILOS CSS DINÂMICOS ===

// Adiciona estilos para efeitos visuais
const dynamicStyles = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.6);
        transform: scale(0);
        animation: ripple-animation 0.6s linear;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    .loading * {
        transition: none !important;
    }
    
    .loaded {
        transition: all 0.3s ease-in-out;
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease-out forwards;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;

// Injeta estilos dinâmicos
const styleSheet = document.createElement('style');
styleSheet.textContent = dynamicStyles;
document.head.appendChild(styleSheet);

// === INICIALIZAÇÃO ===

// Inicializa a aplicação quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// === EXPORTAÇÕES PARA USO GLOBAL ===
window.ProfIAs = {
    authManager: () => authManager,
    showNotification,
    apiRequest,
    currentUser: () => currentUser
};