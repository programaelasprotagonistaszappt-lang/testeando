"""
Schemas para autenticação e gerenciamento de usuários.

Define os modelos de dados para validação de entrada e saída
das APIs relacionadas à autenticação.
"""

from pydantic import BaseModel, EmailStr, validator
from typing import Optional
from datetime import datetime
from app.models.user import UserRole

class UserBase(BaseModel):
    """Schema base para dados de usuário"""
    email: EmailStr
    full_name: str
    institution: Optional[str] = None
    department: Optional[str] = None

class UserCreate(UserBase):
    """Schema para criação de usuário"""
    password: str
    
    @validator('password')
    def validate_password(cls, v):
        """Valida a força da senha"""
        if len(v) < 8:
            raise ValueError('Senha deve ter pelo menos 8 caracteres')
        if not any(c.isupper() for c in v):
            raise ValueError('Senha deve conter pelo menos uma letra maiúscula')
        if not any(c.islower() for c in v):
            raise ValueError('Senha deve conter pelo menos uma letra minúscula')
        if not any(c.isdigit() for c in v):
            raise ValueError('Senha deve conter pelo menos um número')
        return v

class UserLogin(BaseModel):
    """Schema para login de usuário"""
    email: EmailStr
    password: str

class UserResponse(UserBase):
    """Schema para resposta com dados do usuário"""
    id: int
    role: UserRole
    is_active: bool
    is_verified: bool
    created_at: datetime
    last_login: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class Token(BaseModel):
    """Schema para token de autenticação"""
    access_token: str
    token_type: str
    expires_in: int

class TokenData(BaseModel):
    """Schema para dados do token"""
    email: Optional[str] = None