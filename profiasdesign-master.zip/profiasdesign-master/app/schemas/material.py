"""
Schemas para materiais pedagógicos.

Define os modelos de dados para validação de entrada e saída
das APIs relacionadas aos materiais educacionais.
"""

from pydantic import BaseModel, validator
from typing import Optional, List
from datetime import datetime
from app.models.material import MaterialType, MaterialStatus

class MaterialBase(BaseModel):
    """Schema base para materiais"""
    title: str
    description: Optional[str] = None
    subject: Optional[str] = None
    education_level: Optional[str] = None
    target_audience: Optional[str] = None
    estimated_duration: Optional[int] = None

class MaterialCreate(MaterialBase):
    """Schema para criação de material"""
    material_type: MaterialType
    folder_path: Optional[str] = None
    tags: Optional[List[str]] = None
    
    @validator('title')
    def validate_title(cls, v):
        """Valida o título do material"""
        if len(v.strip()) < 3:
            raise ValueError('Título deve ter pelo menos 3 caracteres')
        return v.strip()
    
    @validator('estimated_duration')
    def validate_duration(cls, v):
        """Valida a duração estimada"""
        if v is not None and v <= 0:
            raise ValueError('Duração deve ser um número positivo')
        return v

class MaterialUpdate(BaseModel):
    """Schema para atualização de material"""
    title: Optional[str] = None
    description: Optional[str] = None
    content: Optional[str] = None
    subject: Optional[str] = None
    education_level: Optional[str] = None
    target_audience: Optional[str] = None
    estimated_duration: Optional[int] = None
    folder_path: Optional[str] = None
    tags: Optional[List[str]] = None
    is_favorite: Optional[bool] = None
    is_public: Optional[bool] = None
    status: Optional[MaterialStatus] = None

class MaterialResponse(MaterialBase):
    """Schema para resposta com dados do material"""
    id: int
    material_type: MaterialType
    status: MaterialStatus
    content: str
    ai_model_used: Optional[str] = None
    folder_path: Optional[str] = None
    is_favorite: bool
    is_public: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    last_accessed: Optional[datetime] = None
    creator_id: int
    
    class Config:
        from_attributes = True

class MaterialListResponse(BaseModel):
    """Schema simplificado para listagem de materiais"""
    id: int
    title: str
    description: Optional[str] = None
    material_type: MaterialType
    status: MaterialStatus
    subject: Optional[str] = None
    education_level: Optional[str] = None
    is_favorite: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class FolderCreate(BaseModel):
    """Schema para criação de pasta"""
    name: str
    parent_path: Optional[str] = None
    
    @validator('name')
    def validate_folder_name(cls, v):
        """Valida o nome da pasta"""
        if not v.strip():
            raise ValueError('Nome da pasta não pode estar vazio')
        # Remove caracteres especiais que podem causar problemas
        invalid_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
        for char in invalid_chars:
            if char in v:
                raise ValueError(f'Nome da pasta não pode conter o caractere: {char}')
        return v.strip()

class MaterialStats(BaseModel):
    """Schema para estatísticas de materiais"""
    total_materials: int
    total_favorites: int
    materials_by_type: dict
    materials_by_status: dict
    recent_materials: List[MaterialListResponse]