"""
Schemas para colaboração entre usuários.

Define os modelos de dados para validação de entrada e saída
das APIs relacionadas ao compartilhamento e colaboração em materiais.
"""

from pydantic import BaseModel, EmailStr, validator
from typing import Optional, List
from datetime import datetime
from app.models.collaboration import PermissionType, CollaborationStatus

class CollaborationBase(BaseModel):
    """Schema base para colaborações"""
    permission_type: PermissionType
    invitation_message: Optional[str] = None

class CollaborationCreate(CollaborationBase):
    """Schema para criação de colaboração"""
    material_id: int
    user_email: EmailStr
    expires_in_days: Optional[int] = 30
    
    @validator('expires_in_days')
    def validate_expiration(cls, v):
        """Valida o prazo de expiração"""
        if v is not None and (v < 1 or v > 365):
            raise ValueError('Prazo de expiração deve estar entre 1 e 365 dias')
        return v

class CollaborationUpdate(BaseModel):
    """Schema para atualização de colaboração"""
    permission_type: Optional[PermissionType] = None
    status: Optional[CollaborationStatus] = None
    notification_enabled: Optional[bool] = None

class CollaborationResponse(BaseModel):
    """Schema para resposta com dados da colaboração"""
    id: int
    material_id: int
    material_title: str
    material_description: Optional[str] = None
    owner_name: Optional[str] = None
    owner_email: Optional[str] = None
    collaborator_name: Optional[str] = None
    collaborator_email: Optional[str] = None
    permission_type: PermissionType
    status: CollaborationStatus
    created_at: datetime
    accepted_at: Optional[datetime] = None
    last_activity: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class ShareRequest(BaseModel):
    """Schema para requisição de compartilhamento"""
    material_id: int
    user_email: EmailStr
    permission_type: PermissionType
    message: Optional[str] = None
    expires_in_days: Optional[int] = 30
    notify_user: bool = True
    
    @validator('message')
    def validate_message(cls, v):
        """Valida a mensagem do convite"""
        if v and len(v) > 500:
            raise ValueError('Mensagem do convite não pode exceder 500 caracteres')
        return v

class ShareResponse(BaseModel):
    """Schema para resposta do compartilhamento"""
    collaboration_id: int
    material_title: str
    shared_with: str
    permission_type: PermissionType
    status: CollaborationStatus
    created_at: datetime
    expires_at: Optional[datetime] = None

class CommentBase(BaseModel):
    """Schema base para comentários"""
    content: str
    
    @validator('content')
    def validate_content(cls, v):
        """Valida o conteúdo do comentário"""
        if not v.strip():
            raise ValueError('Comentário não pode estar vazio')
        if len(v) > 1000:
            raise ValueError('Comentário não pode exceder 1000 caracteres')
        return v.strip()

class CommentCreate(CommentBase):
    """Schema para criação de comentário"""
    parent_comment_id: Optional[int] = None

class CommentUpdate(BaseModel):
    """Schema para atualização de comentário"""
    content: Optional[str] = None
    is_resolved: Optional[bool] = None

class CommentResponse(CommentBase):
    """Schema para resposta com dados do comentário"""
    id: int
    material_id: int
    user_name: str
    parent_comment_id: Optional[int] = None
    is_resolved: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    replies: Optional[List['CommentResponse']] = None
    
    class Config:
        from_attributes = True

class CollaborationInvite(BaseModel):
    """Schema para convite de colaboração"""
    material_title: str
    inviter_name: str
    permission_type: PermissionType
    message: Optional[str] = None
    expires_at: Optional[datetime] = None
    accept_url: str
    decline_url: str

class CollaborationStats(BaseModel):
    """Schema para estatísticas de colaboração"""
    total_collaborations: int
    active_collaborations: int
    materials_shared: int
    materials_received: int
    pending_invites: int
    recent_activity: List[dict]