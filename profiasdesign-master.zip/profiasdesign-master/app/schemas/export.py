"""
Schemas para exportação de materiais.

Define os modelos de dados para validação de entrada e saída
das APIs relacionadas à exportação de materiais em diferentes formatos.
"""

from pydantic import BaseModel, validator
from typing import Optional, List
from datetime import datetime
from app.models.material import ExportFormat

class ExportRequest(BaseModel):
    """Schema para requisição de exportação"""
    format: ExportFormat
    include_metadata: bool = True
    custom_template: Optional[str] = None
    
    @validator('format')
    def validate_format(cls, v):
        """Valida o formato de exportação"""
        if v not in [ExportFormat.PDF, ExportFormat.DOCX, ExportFormat.PPTX]:
            raise ValueError('Formato de exportação não suportado')
        return v

class ExportResponse(BaseModel):
    """Schema para resposta da exportação"""
    material_id: int
    format: ExportFormat
    filename: str
    file_size: int  # Tamanho em bytes
    download_url: str
    generated_at: datetime
    expires_at: Optional[datetime] = None

class ExportHistory(BaseModel):
    """Schema para histórico de exportações"""
    format: str
    filename: str
    file_size: int
    generated_at: str
    download_url: str
    is_available: bool = True

class ExportTemplate(BaseModel):
    """Schema para templates de exportação"""
    id: str
    name: str
    description: str
    format: ExportFormat
    preview_url: Optional[str] = None
    is_default: bool = False

class BulkExportRequest(BaseModel):
    """Schema para exportação em lote"""
    material_ids: List[int]
    format: ExportFormat
    compress_files: bool = True
    
    @validator('material_ids')
    def validate_material_ids(cls, v):
        """Valida a lista de IDs de materiais"""
        if not v:
            raise ValueError('Lista de materiais não pode estar vazia')
        if len(v) > 50:
            raise ValueError('Máximo de 50 materiais por exportação em lote')
        return v

class ExportStats(BaseModel):
    """Schema para estatísticas de exportação"""
    total_exports: int
    exports_by_format: dict
    total_file_size: int
    most_exported_material: Optional[str] = None
    recent_exports: List[ExportHistory]