"""
Schemas para geração de conteúdo com IA.

Define os modelos de dados para validação de entrada e saída
das APIs relacionadas à geração de materiais com inteligência artificial.
"""

from pydantic import BaseModel, validator
from typing import Optional, Dict, Any, List
from datetime import datetime

class ModelParameters(BaseModel):
    """Schema para parâmetros de geração do modelo de IA"""
    temperature: float = 0.7
    max_tokens: int = 2000
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    
    @validator('temperature')
    def validate_temperature(cls, v):
        """Valida o parâmetro de temperatura"""
        if not 0.0 <= v <= 2.0:
            raise ValueError('Temperature deve estar entre 0.0 e 2.0')
        return v
    
    @validator('max_tokens')
    def validate_max_tokens(cls, v):
        """Valida o número máximo de tokens"""
        if not 1 <= v <= 4000:
            raise ValueError('Max tokens deve estar entre 1 e 4000')
        return v
    
    @validator('top_p')
    def validate_top_p(cls, v):
        """Valida o parâmetro top_p"""
        if not 0.0 <= v <= 1.0:
            raise ValueError('Top_p deve estar entre 0.0 e 1.0')
        return v

class GenerationRequest(BaseModel):
    """Schema para requisição de geração de conteúdo"""
    material_id: int
    ai_model: str
    title: str
    description: Optional[str] = None
    subject: str
    education_level: str
    target_audience: str
    estimated_duration: Optional[int] = None
    parameters: ModelParameters = ModelParameters()
    
    @validator('ai_model')
    def validate_ai_model(cls, v):
        """Valida o modelo de IA selecionado"""
        allowed_models = ['openai', 'anthropic', 'google', 'groq', 'cohere']
        if v not in allowed_models:
            raise ValueError(f'Modelo deve ser um dos seguintes: {", ".join(allowed_models)}')
        return v
    
    @validator('education_level')
    def validate_education_level(cls, v):
        """Valida o nível de educação"""
        allowed_levels = [
            'infantil', 'fundamental_1', 'fundamental_2', 
            'medio', 'tecnico', 'superior', 'pos_graduacao'
        ]
        if v not in allowed_levels:
            raise ValueError(f'Nível de educação deve ser um dos seguintes: {", ".join(allowed_levels)}')
        return v

class GenerationResponse(BaseModel):
    """Schema para resposta da geração de conteúdo"""
    material_id: int
    content: str
    ai_model: str
    processing_time: float
    tokens_used: int
    success: bool
    generated_at: datetime = datetime.utcnow()

class PromptTemplate(BaseModel):
    """Schema para templates de prompt"""
    id: str
    name: str
    description: str
    template: str
    variables: List[str]
    material_types: List[str]
    
class AIModelInfo(BaseModel):
    """Schema para informações sobre modelos de IA"""
    id: str
    name: str
    description: str
    strengths: List[str]
    best_for: List[str]
    available: bool
    max_tokens: int
    supports_streaming: bool = False

class GenerationHistory(BaseModel):
    """Schema para histórico de gerações"""
    id: int
    material_title: str
    ai_model: str
    prompt_preview: str  # Primeiros 100 caracteres do prompt
    success: bool
    processing_time: float
    tokens_used: Optional[int] = None
    created_at: datetime
    user_rating: Optional[int] = None
    
    class Config:
        from_attributes = True

class PromptReuseRequest(BaseModel):
    """Schema para reutilização de prompts"""
    interaction_id: int
    material_id: int
    modifications: Optional[Dict[str, Any]] = None

class EthicalGuidelines(BaseModel):
    """Schema para diretrizes éticas de uso da IA"""
    title: str
    content: str
    importance_level: str  # 'high', 'medium', 'low'
    category: str  # 'bias', 'accuracy', 'privacy', 'transparency'
    
class AIUsageStats(BaseModel):
    """Schema para estatísticas de uso da IA"""
    total_generations: int
    successful_generations: int
    average_processing_time: float
    most_used_model: str
    total_tokens_used: int
    generations_by_model: Dict[str, int]
    recent_activity: List[GenerationHistory]