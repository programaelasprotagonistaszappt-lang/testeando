"""
Configurações centrais da aplicação ProfIAs.

Este módulo centraliza todas as configurações da aplicação,
incluindo variáveis de ambiente, configurações de banco de dados,
chaves de API e outras configurações importantes.
"""

from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    """
    Classe que define todas as configurações da aplicação.
    Utiliza Pydantic para validação automática e carregamento de variáveis de ambiente.
    """
    
    # === CONFIGURAÇÕES BÁSICAS ===
    app_name: str = "ProfIAs"
    app_version: str = "1.0.0"
    environment: str = "development"
    debug: bool = True
    
    # === CONFIGURAÇÕES DO BANCO DE DADOS ===
    database_url: str = "postgresql://profias_user:profias_password@localhost:5432/profias_db"
    
    # === CONFIGURAÇÕES DE SEGURANÇA ===
    secret_key: str = "sua_chave_secreta_muito_forte_aqui"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # === CHAVES DAS APIs DE IA ===
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    google_api_key: str = ""
    groq_api_key: str = ""
    cohere_api_key: str = ""
    
    # === CONFIGURAÇÕES DE UPLOAD ===
    max_file_size: int = 10485760  # 10MB
    allowed_file_types: List[str] = ["pdf", "docx", "pptx", "txt"]
    upload_directory: str = "uploads"
    
    # === CONFIGURAÇÕES DE CORS ===
    allowed_origins: List[str] = ["*"]
    
    # === CONFIGURAÇÕES DE CACHE ===
    redis_url: str = "redis://localhost:6379/0"
    
    class Config:
        # Arquivo de onde carregar as variáveis de ambiente
        env_file = ".env"
        # Permite que variáveis de ambiente sobrescrevam valores padrão
        env_file_encoding = "utf-8"

# Instância global das configurações
# Esta instância é importada por outros módulos da aplicação
settings = Settings()