"""
Modelo de dados para usuários da plataforma.

Define a estrutura da tabela de usuários e suas relações,
incluindo informações de perfil, autenticação e preferências.
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, Enum
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base
import enum

class UserRole(enum.Enum):
    """
    Enumera os diferentes tipos de usuário na plataforma.
    Permite controle de acesso baseado em papéis.
    """
    TEACHER = "teacher"  # Professor regular
    ADMIN = "admin"      # Administrador do sistema
    COORDINATOR = "coordinator"  # Coordenador pedagógico

class EducationLevel(enum.Enum):
    """
    Níveis de ensino que o usuário pode trabalhar.
    Usado para personalizar a geração de materiais.
    """
    INFANTIL = "infantil"
    FUNDAMENTAL_I = "fundamental_1"
    FUNDAMENTAL_II = "fundamental_2"
    MEDIO = "medio"
    TECNICO = "tecnico"
    SUPERIOR = "superior"
    POS_GRADUACAO = "pos_graduacao"

class User(Base):
    """
    Modelo principal para usuários da plataforma.
    
    Armazena informações de identificação, autenticação,
    perfil educacional e preferências do usuário.
    """
    __tablename__ = "users"

    # === IDENTIFICAÇÃO BÁSICA ===
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    
    # === AUTENTICAÇÃO ===
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    role = Column(Enum(UserRole), default=UserRole.TEACHER)
    
    # === PERFIL EDUCACIONAL ===
    institution = Column(String(255))  # Instituição de ensino
    department = Column(String(255))   # Departamento/área
    subjects = Column(Text)  # Disciplinas que leciona (JSON)
    education_levels = Column(Text)  # Níveis que atua (JSON)
    
    # === PREFERÊNCIAS ===
    preferred_ai_model = Column(String(50), default="openai")
    language_preference = Column(String(10), default="pt-BR")
    
    # === METADADOS ===
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_login = Column(DateTime(timezone=True))
    
    # === RELACIONAMENTOS ===
    # Um usuário pode ter muitos materiais criados
    materials = relationship("Material", back_populates="creator")
    
    # Um usuário pode ter muitas interações com IA
    ai_interactions = relationship("AIInteraction", back_populates="user")
    
    # Um usuário pode colaborar em muitos materiais
    collaborations = relationship("Collaboration", back_populates="user")

    def __repr__(self):
        return f"<User(email='{self.email}', name='{self.full_name}')>"