"""
Modelo de dados para colaboração entre usuários.

Define como os materiais podem ser compartilhados entre usuários,
incluindo permissões, comentários e histórico de colaboração.
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, ForeignKey, Enum
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base
import enum

class PermissionType(enum.Enum):
    """
    Tipos de permissão que podem ser concedidas em colaborações.
    Define o que cada colaborador pode fazer com o material.
    """
    VIEW = "view"        # Apenas visualizar
    COMMENT = "comment"  # Visualizar e comentar
    EDIT = "edit"       # Visualizar, comentar e editar
    ADMIN = "admin"     # Controle total (incluindo gerenciar permissões)

class CollaborationStatus(enum.Enum):
    """
    Status da colaboração entre usuários.
    Permite controle do fluxo de trabalho colaborativo.
    """
    PENDING = "pending"    # Convite pendente
    ACTIVE = "active"      # Colaboração ativa
    SUSPENDED = "suspended"  # Temporariamente suspensa
    ENDED = "ended"        # Colaboração finalizada

class Collaboration(Base):
    """
    Modelo para gerenciar colaborações em materiais.
    
    Representa o compartilhamento de um material entre usuários,
    incluindo permissões, status e histórico da colaboração.
    """
    __tablename__ = "collaborations"

    # === IDENTIFICAÇÃO ===
    id = Column(Integer, primary_key=True, index=True)
    
    # === RELACIONAMENTOS ===
    material_id = Column(Integer, ForeignKey("materials.id"), nullable=False)
    material = relationship("Material", back_populates="collaborations")
    
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    user = relationship("User", back_populates="collaborations")
    
    # === PERMISSÕES ===
    permission_type = Column(Enum(PermissionType), nullable=False)
    status = Column(Enum(CollaborationStatus), default=CollaborationStatus.PENDING)
    
    # === METADADOS DA COLABORAÇÃO ===
    invited_by = Column(Integer, ForeignKey("users.id"))  # Quem fez o convite
    invitation_message = Column(Text)  # Mensagem do convite
    
    # === DATAS IMPORTANTES ===
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    accepted_at = Column(DateTime(timezone=True))  # Quando aceitou o convite
    last_activity = Column(DateTime(timezone=True))  # Última atividade
    expires_at = Column(DateTime(timezone=True))  # Expiração da colaboração
    
    # === CONFIGURAÇÕES ===
    can_invite_others = Column(Boolean, default=False)  # Pode convidar outros
    notification_enabled = Column(Boolean, default=True)  # Recebe notificações
    
    def __repr__(self):
        return f"<Collaboration(material_id={self.material_id}, user_id={self.user_id}, permission='{self.permission_type}')>"

class Comment(Base):
    """
    Modelo para comentários em materiais colaborativos.
    
    Permite que colaboradores deixem feedback e sugestões
    em materiais compartilhados.
    """
    __tablename__ = "comments"

    # === IDENTIFICAÇÃO ===
    id = Column(Integer, primary_key=True, index=True)
    
    # === RELACIONAMENTOS ===
    material_id = Column(Integer, ForeignKey("materials.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # === CONTEÚDO ===
    content = Column(Text, nullable=False)
    is_resolved = Column(Boolean, default=False)  # Se o comentário foi resolvido
    
    # === HIERARQUIA (PARA RESPOSTAS) ===
    parent_comment_id = Column(Integer, ForeignKey("comments.id"))
    
    # === METADADOS ===
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    def __repr__(self):
        return f"<Comment(material_id={self.material_id}, user_id={self.user_id})>"