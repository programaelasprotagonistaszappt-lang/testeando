"""
Modelo de dados para materiais pedagógicos.

Define a estrutura para armazenar materiais criados pelos usuários,
incluindo metadados, conteúdo e informações de organização.
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, ForeignKey, Enum
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base
import enum

class MaterialType(enum.Enum):
    """
    Tipos de materiais que podem ser gerados na plataforma.
    Cada tipo tem características específicas de geração e formatação.
    """
    LESSON_PLAN = "lesson_plan"      # Plano de aula
    EXERCISE = "exercise"            # Lista de exercícios
    QUIZ = "quiz"                   # Quiz/questionário
    PRESENTATION = "presentation"    # Apresentação
    WORKSHEET = "worksheet"         # Folha de atividades
    ASSESSMENT = "assessment"       # Avaliação
    PROJECT = "project"             # Projeto pedagógico

class MaterialStatus(enum.Enum):
    """
    Status do material no processo de criação e aprovação.
    Permite controle do fluxo de trabalho.
    """
    DRAFT = "draft"           # Rascunho
    GENERATED = "generated"   # Gerado pela IA
    REVIEWED = "reviewed"     # Revisado pelo professor
    PUBLISHED = "published"   # Publicado/finalizado
    ARCHIVED = "archived"     # Arquivado

class ExportFormat(enum.Enum):
    """
    Formatos disponíveis para exportação dos materiais.
    Cada formato tem suas características específicas.
    """
    PDF = "pdf"      # Documento portátil
    DOCX = "docx"    # Documento Word editável
    PPTX = "pptx"    # Apresentação PowerPoint
    HTML = "html"    # Página web

class Material(Base):
    """
    Modelo principal para materiais pedagógicos.
    
    Armazena todo o conteúdo gerado, metadados educacionais,
    informações de organização e histórico de modificações.
    """
    __tablename__ = "materials"

    # === IDENTIFICAÇÃO ===
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    
    # === RELACIONAMENTO COM USUÁRIO ===
    creator_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    creator = relationship("User", back_populates="materials")
    
    # === CLASSIFICAÇÃO EDUCACIONAL ===
    subject = Column(String(100), index=True)  # Disciplina
    education_level = Column(String(50), index=True)  # Nível de ensino
    target_audience = Column(Text)  # Descrição do público-alvo
    estimated_duration = Column(Integer)  # Duração em minutos
    
    # === CONTEÚDO ===
    content = Column(Text, nullable=False)  # Conteúdo principal
    material_type = Column(Enum(MaterialType), nullable=False)
    status = Column(Enum(MaterialStatus), default=MaterialStatus.DRAFT)
    
    # === METADADOS DE IA ===
    ai_model_used = Column(String(50))  # Modelo de IA utilizado
    prompt_used = Column(Text)  # Prompt original usado
    generation_parameters = Column(Text)  # Parâmetros em JSON
    
    # === ORGANIZAÇÃO ===
    folder_path = Column(String(500))  # Caminho da pasta
    tags = Column(Text)  # Tags em JSON
    is_favorite = Column(Boolean, default=False)
    is_public = Column(Boolean, default=False)  # Visível para outros usuários
    
    # === EXPORTAÇÃO ===
    exported_formats = Column(Text)  # Formatos já exportados (JSON)
    file_paths = Column(Text)  # Caminhos dos arquivos exportados (JSON)
    
    # === METADADOS ===
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_accessed = Column(DateTime(timezone=True))
    
    # === RELACIONAMENTOS ===
    # Um material pode ter muitas interações de IA associadas
    ai_interactions = relationship("AIInteraction", back_populates="material")
    
    # Um material pode ser compartilhado com muitos usuários
    collaborations = relationship("Collaboration", back_populates="material")

    def __repr__(self):
        return f"<Material(title='{self.title}', type='{self.material_type}')>"