"""
Modelo de dados para interações com IA.

Registra todas as interações dos usuários com os modelos de IA,
permitindo auditoria, reutilização de prompts e análise de uso.
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, Float, ForeignKey, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base

class AIInteraction(Base):
    """
    Modelo para registrar interações com modelos de IA.
    
    Cada interação representa uma requisição feita a um modelo de IA,
    incluindo o prompt enviado, a resposta recebida e metadados da operação.
    """
    __tablename__ = "ai_interactions"

    # === IDENTIFICAÇÃO ===
    id = Column(Integer, primary_key=True, index=True)
    
    # === RELACIONAMENTOS ===
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    user = relationship("User", back_populates="ai_interactions")
    
    material_id = Column(Integer, ForeignKey("materials.id"), nullable=True)
    material = relationship("Material", back_populates="ai_interactions")
    
    # === DADOS DA REQUISIÇÃO ===
    ai_model = Column(String(50), nullable=False)  # Modelo usado (openai, claude, etc.)
    model_version = Column(String(50))  # Versão específica do modelo
    prompt = Column(Text, nullable=False)  # Prompt enviado
    system_prompt = Column(Text)  # Prompt de sistema, se usado
    
    # === PARÂMETROS DE GERAÇÃO ===
    temperature = Column(Float, default=0.7)  # Criatividade da resposta
    max_tokens = Column(Integer, default=1000)  # Limite de tokens
    top_p = Column(Float, default=1.0)  # Nucleus sampling
    frequency_penalty = Column(Float, default=0.0)  # Penalidade de frequência
    presence_penalty = Column(Float, default=0.0)  # Penalidade de presença
    
    # === RESPOSTA ===
    response = Column(Text)  # Resposta completa da IA
    response_tokens = Column(Integer)  # Número de tokens na resposta
    
    # === METADADOS DA OPERAÇÃO ===
    request_timestamp = Column(DateTime(timezone=True), server_default=func.now())
    response_timestamp = Column(DateTime(timezone=True))
    processing_time = Column(Float)  # Tempo de processamento em segundos
    
    # === STATUS E QUALIDADE ===
    success = Column(Boolean, default=True)  # Se a requisição foi bem-sucedida
    error_message = Column(Text)  # Mensagem de erro, se houver
    user_rating = Column(Integer)  # Avaliação do usuário (1-5)
    user_feedback = Column(Text)  # Feedback textual do usuário
    
    # === CUSTOS (OPCIONAL) ===
    cost_estimate = Column(Float)  # Custo estimado da requisição
    
    # === REUTILIZAÇÃO ===
    reused_count = Column(Integer, default=0)  # Quantas vezes foi reutilizado
    is_template = Column(Boolean, default=False)  # Se é um template salvo
    template_name = Column(String(255))  # Nome do template, se aplicável

    def __repr__(self):
        return f"<AIInteraction(model='{self.ai_model}', user_id={self.user_id})>"