"""
Roteador para geração de conteúdo com IA.

Implementa a orquestração de diferentes modelos de IA para gerar
materiais pedagógicos personalizados baseados nos parâmetros do usuário.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Dict, Any, Optional
from datetime import datetime
import json
import asyncio
import httpx

from app.database import get_db
from app.models.user import User
from app.models.material import Material, MaterialStatus
from app.models.ai_interaction import AIInteraction
from app.routers.auth import get_current_user
from app.core.config import settings
from app.schemas.ai_generation import (
    GenerationRequest, GenerationResponse, 
    PromptTemplate, ModelParameters
)

router = APIRouter()

class AIOrchestrator:
    """
    Classe responsável por orquestrar as chamadas para diferentes modelos de IA.
    
    Centraliza a lógica de comunicação com APIs externas e padroniza
    o formato das respostas independente do modelo utilizado.
    """
    
    def __init__(self):
        self.models = {
            "openai": self._call_openai,
            "anthropic": self._call_anthropic,
            "google": self._call_google,
            "groq": self._call_groq,
            "cohere": self._call_cohere
        }
    
    async def generate_content(
        self, 
        model: str, 
        prompt: str, 
        parameters: ModelParameters
    ) -> Dict[str, Any]:
        """
        Gera conteúdo usando o modelo especificado.
        
        Args:
            model: Nome do modelo de IA a ser usado
            prompt: Prompt formatado para envio
            parameters: Parâmetros de geração
            
        Returns:
            Dict contendo a resposta e metadados
        """
        if model not in self.models:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Modelo '{model}' não suportado"
            )
        
        start_time = datetime.utcnow()
        
        try:
            response = await self.models[model](prompt, parameters)
            end_time = datetime.utcnow()
            
            return {
                "content": response["content"],
                "model": model,
                "processing_time": (end_time - start_time).total_seconds(),
                "tokens_used": response.get("tokens_used", 0),
                "success": True
            }
            
        except Exception as e:
            end_time = datetime.utcnow()
            return {
                "content": None,
                "model": model,
                "processing_time": (end_time - start_time).total_seconds(),
                "error": str(e),
                "success": False
            }
    
    async def _call_openai(self, prompt: str, parameters: ModelParameters) -> Dict:
        """Chama a API da OpenAI (GPT)"""
        if not settings.openai_api_key:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Chave da API OpenAI não configurada"
            )
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {settings.openai_api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "gpt-3.5-turbo",
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": parameters.temperature,
                    "max_tokens": parameters.max_tokens
                },
                timeout=60.0
            )
            
            if response.status_code != 200:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Erro na API da OpenAI"
                )
            
            data = response.json()
            return {
                "content": data["choices"][0]["message"]["content"],
                "tokens_used": data["usage"]["total_tokens"]
            }
    
    async def _call_anthropic(self, prompt: str, parameters: ModelParameters) -> Dict:
        """Chama a API da Anthropic (Claude)"""
        if not settings.anthropic_api_key:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Chave da API Anthropic não configurada"
            )
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": settings.anthropic_api_key,
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01"
                },
                json={
                    "model": "claude-3-haiku-20240307",
                    "max_tokens": parameters.max_tokens,
                    "messages": [{"role": "user", "content": prompt}]
                },
                timeout=60.0
            )
            
            if response.status_code != 200:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Erro na API da Anthropic"
                )
            
            data = response.json()
            return {
                "content": data["content"][0]["text"],
                "tokens_used": data["usage"]["input_tokens"] + data["usage"]["output_tokens"]
            }
    
    async def _call_google(self, prompt: str, parameters: ModelParameters) -> Dict:
        """Chama a API do Google (Gemini)"""
        # Implementação simplificada - em produção, usar a biblioteca oficial
        return {
            "content": f"[Resposta simulada do Gemini para: {prompt[:50]}...]",
            "tokens_used": 100
        }
    
    async def _call_groq(self, prompt: str, parameters: ModelParameters) -> Dict:
        """Chama a API da Groq"""
        # Implementação simplificada - em produção, usar a biblioteca oficial
        return {
            "content": f"[Resposta simulada do Groq para: {prompt[:50]}...]",
            "tokens_used": 100
        }
    
    async def _call_cohere(self, prompt: str, parameters: ModelParameters) -> Dict:
        """Chama a API da Cohere"""
        # Implementação simplificada - em produção, usar a biblioteca oficial
        return {
            "content": f"[Resposta simulada do Cohere para: {prompt[:50]}...]",
            "tokens_used": 100
        }

# Instância global do orquestrador
ai_orchestrator = AIOrchestrator()

class PromptBuilder:
    """
    Classe responsável por construir prompts otimizados para cada tipo de material.
    
    Utiliza templates específicos e engenharia de prompt para maximizar
    a qualidade dos materiais gerados pela IA.
    """
    
    @staticmethod
    def build_lesson_plan_prompt(request: GenerationRequest) -> str:
        """Constrói prompt para plano de aula"""
        return f"""
Você é um assistente pedagógico especialista em educação. Crie um plano de aula detalhado e bem estruturado com as seguintes especificações:

**Informações Básicas:**
- Disciplina: {request.subject}
- Nível de ensino: {request.education_level}
- Duração: {request.estimated_duration} minutos
- Público-alvo: {request.target_audience}

**Tema:** {request.title}
**Descrição:** {request.description}

**Estrutura Obrigatória:**
1. **Título da Aula:** Criativo e relacionado ao tema
2. **Objetivos de Aprendizagem:** Claros e mensuráveis (o que os alunos devem conseguir fazer ao final)
3. **Recursos e Materiais:** Lista completa do que será necessário
4. **Desenvolvimento da Aula:**
   - Introdução (motivação e contextualização)
   - Desenvolvimento (atividade principal passo a passo)
   - Conclusão (síntese e fechamento)
5. **Avaliação:** Como verificar se os objetivos foram alcançados
6. **Atividades Complementares:** Sugestões para aprofundamento

**Diretrizes:**
- Use linguagem adequada ao nível de ensino especificado
- Inclua metodologias ativas quando apropriado
- Considere diferentes estilos de aprendizagem
- Seja específico e prático nas orientações
- Formate usando markdown para melhor legibilidade

Gere um plano de aula completo e pronto para uso.
"""
    
    @staticmethod
    def build_exercise_prompt(request: GenerationRequest) -> str:
        """Constrói prompt para lista de exercícios"""
        return f"""
Crie uma lista de exercícios educacionais sobre o tema "{request.title}" com as seguintes especificações:

**Contexto Educacional:**
- Disciplina: {request.subject}
- Nível: {request.education_level}
- Público-alvo: {request.target_audience}
- Tempo estimado: {request.estimated_duration} minutos

**Descrição do Conteúdo:** {request.description}

**Estrutura dos Exercícios:**
1. **Exercícios de Fixação** (3-5 questões básicas)
2. **Exercícios de Aplicação** (3-4 questões intermediárias)
3. **Exercícios de Aprofundamento** (2-3 questões avançadas)

**Para cada exercício, inclua:**
- Enunciado claro e objetivo
- Nível de dificuldade
- Resposta ou gabarito
- Explicação da resolução quando necessário

**Diretrizes:**
- Varie os tipos de questão (múltipla escolha, dissertativa, prática)
- Inclua situações-problema contextualizadas
- Use linguagem apropriada ao nível de ensino
- Formate de forma clara e organizada

Gere uma lista completa e diversificada de exercícios.
"""
    
    @staticmethod
    def build_quiz_prompt(request: GenerationRequest) -> str:
        """Constrói prompt para quiz/questionário"""
        return f"""
Desenvolva um quiz interativo sobre "{request.title}" com as seguintes características:

**Especificações:**
- Disciplina: {request.subject}
- Nível: {request.education_level}
- Duração: {request.estimated_duration} minutos
- Público: {request.target_audience}

**Conteúdo:** {request.description}

**Estrutura do Quiz:**
1. **Questões de Múltipla Escolha** (5-7 questões)
2. **Questões Verdadeiro/Falso** (3-5 questões)
3. **Questões Dissertativas Curtas** (2-3 questões)

**Para cada questão, forneça:**
- Enunciado claro
- Alternativas (quando aplicável)
- Resposta correta
- Explicação/justificativa
- Pontuação sugerida

**Critérios:**
- Questões progressivas (fácil → difícil)
- Cobertura equilibrada do conteúdo
- Linguagem adequada ao público
- Feedback educativo para cada resposta

Crie um quiz completo e envolvente.
"""

# Instância do construtor de prompts
prompt_builder = PromptBuilder()

@router.post("/generate", response_model=GenerationResponse)
async def generate_material_content(
    request: GenerationRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Gera conteúdo para um material usando IA.
    
    Este é o endpoint principal para geração de materiais pedagógicos.
    Utiliza engenharia de prompt avançada e registra toda a interação
    para auditoria e reutilização futura.
    """
    
    # Busca o material no banco de dados
    result = await db.execute(
        select(Material).where(Material.id == request.material_id)
    )
    material = result.scalar_one_or_none()
    
    if not material or material.creator_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Constrói o prompt baseado no tipo de material
    prompt_methods = {
        "lesson_plan": prompt_builder.build_lesson_plan_prompt,
        "exercise": prompt_builder.build_exercise_prompt,
        "quiz": prompt_builder.build_quiz_prompt
    }
    
    prompt_method = prompt_methods.get(
        material.material_type.value,
        prompt_builder.build_lesson_plan_prompt  # Fallback
    )
    
    prompt = prompt_method(request)
    
    # Registra a interação antes de enviar para a IA
    ai_interaction = AIInteraction(
        user_id=current_user.id,
        material_id=material.id,
        ai_model=request.ai_model,
        prompt=prompt,
        temperature=request.parameters.temperature,
        max_tokens=request.parameters.max_tokens,
        request_timestamp=datetime.utcnow()
    )
    
    db.add(ai_interaction)
    await db.commit()
    
    try:
        # Gera o conteúdo usando o modelo especificado
        result = await ai_orchestrator.generate_content(
            model=request.ai_model,
            prompt=prompt,
            parameters=request.parameters
        )
        
        if result["success"]:
            # Atualiza o material com o conteúdo gerado
            material.content = result["content"]
            material.status = MaterialStatus.GENERATED
            material.ai_model_used = request.ai_model
            material.prompt_used = prompt
            material.generation_parameters = json.dumps(request.parameters.dict())
            material.updated_at = datetime.utcnow()
            
            # Atualiza a interação com a resposta
            ai_interaction.response = result["content"]
            ai_interaction.response_timestamp = datetime.utcnow()
            ai_interaction.processing_time = result["processing_time"]
            ai_interaction.response_tokens = result["tokens_used"]
            ai_interaction.success = True
            
            await db.commit()
            
            return GenerationResponse(
                material_id=material.id,
                content=result["content"],
                ai_model=request.ai_model,
                processing_time=result["processing_time"],
                tokens_used=result["tokens_used"],
                success=True
            )
        
        else:
            # Registra o erro na interação
            ai_interaction.success = False
            ai_interaction.error_message = result["error"]
            ai_interaction.processing_time = result["processing_time"]
            
            await db.commit()
            
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Erro na geração: {result['error']}"
            )
    
    except Exception as e:
        # Registra erro inesperado
        ai_interaction.success = False
        ai_interaction.error_message = str(e)
        await db.commit()
        raise

@router.get("/models")
async def list_available_models():
    """
    Lista os modelos de IA disponíveis na plataforma.
    
    Retorna informações sobre cada modelo, incluindo capacidades,
    limitações e recomendações de uso.
    """
    models = [
        {
            "id": "openai",
            "name": "OpenAI GPT-3.5",
            "description": "Modelo versátil para geração de texto educacional",
            "strengths": ["Versatilidade", "Qualidade consistente", "Rapidez"],
            "best_for": ["Planos de aula", "Exercícios gerais"],
            "available": bool(settings.openai_api_key)
        },
        {
            "id": "anthropic",
            "name": "Anthropic Claude",
            "description": "Modelo focado em segurança e precisão",
            "strengths": ["Precisão", "Segurança", "Raciocínio"],
            "best_for": ["Conteúdo técnico", "Avaliações"],
            "available": bool(settings.anthropic_api_key)
        },
        {
            "id": "google",
            "name": "Google Gemini",
            "description": "Modelo multimodal do Google",
            "strengths": ["Multimodalidade", "Conhecimento atualizado"],
            "best_for": ["Conteúdo visual", "Pesquisa"],
            "available": bool(settings.google_api_key)
        },
        {
            "id": "groq",
            "name": "Groq Llama",
            "description": "Modelo open-source de alta velocidade",
            "strengths": ["Velocidade", "Open-source", "Eficiência"],
            "best_for": ["Geração rápida", "Prototipagem"],
            "available": bool(settings.groq_api_key)
        },
        {
            "id": "cohere",
            "name": "Cohere Command",
            "description": "Modelo especializado em tarefas de linguagem",
            "strengths": ["Especialização", "Customização"],
            "best_for": ["Tarefas específicas", "Análise de texto"],
            "available": bool(settings.cohere_api_key)
        }
    ]
    
    return {"models": models}

@router.get("/templates")
async def list_prompt_templates():
    """
    Lista templates de prompt disponíveis.
    
    Fornece templates pré-definidos que os usuários podem usar
    como base para criar seus próprios prompts personalizados.
    """
    templates = [
        {
            "id": "lesson_plan_basic",
            "name": "Plano de Aula Básico",
            "description": "Template padrão para planos de aula",
            "material_types": ["lesson_plan"],
            "variables": ["subject", "level", "duration", "topic"]
        },
        {
            "id": "exercise_progressive",
            "name": "Exercícios Progressivos",
            "description": "Lista de exercícios com dificuldade crescente",
            "material_types": ["exercise"],
            "variables": ["subject", "level", "topic", "quantity"]
        },
        {
            "id": "quiz_interactive",
            "name": "Quiz Interativo",
            "description": "Questionário com feedback imediato",
            "material_types": ["quiz"],
            "variables": ["subject", "level", "topic", "question_count"]
        }
    ]
    
    return {"templates": templates}