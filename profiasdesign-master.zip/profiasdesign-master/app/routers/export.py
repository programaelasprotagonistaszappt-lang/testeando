"""
Roteador para exportação de materiais em diferentes formatos.

Implementa o pipeline de conversão de materiais para formatos
editáveis (DOCX, PPTX) e portáveis (PDF) para distribuição offline.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Optional
from datetime import datetime
import json
import os
import tempfile
from pathlib import Path

# Bibliotecas para geração de documentos
from docx import Document
from docx.shared import Inches
from pptx import Presentation
from pptx.util import Inches as PptxInches
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

from app.database import get_db
from app.models.user import User
from app.models.material import Material, ExportFormat
from app.routers.auth import get_current_user
from app.schemas.export import ExportRequest, ExportResponse

router = APIRouter()

class DocumentGenerator:
    """
    Classe responsável por gerar documentos em diferentes formatos.
    
    Converte o conteúdo textual dos materiais em documentos
    formatados e prontos para distribuição.
    """
    
    def __init__(self, upload_dir: str = "uploads/exports"):
        self.upload_dir = Path(upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)
    
    async def generate_docx(self, material: Material, user: User) -> str:
        """
        Gera um documento Word (.docx) do material.
        
        Cria um documento formatado com cabeçalho, conteúdo
        estruturado e metadados do material.
        """
        # Cria um novo documento
        doc = Document()
        
        # Adiciona cabeçalho com informações do material
        header = doc.sections[0].header
        header_para = header.paragraphs[0]
        header_para.text = f"ProfIAs - {material.title}"
        
        # Título principal
        title = doc.add_heading(material.title, 0)
        title.alignment = 1  # Centralizado
        
        # Informações do material
        info_table = doc.add_table(rows=6, cols=2)
        info_table.style = 'Table Grid'
        
        info_data = [
            ("Disciplina:", material.subject or "Não especificada"),
            ("Nível de Ensino:", material.education_level or "Não especificado"),
            ("Duração Estimada:", f"{material.estimated_duration} minutos" if material.estimated_duration else "Não especificada"),
            ("Público-Alvo:", material.target_audience or "Não especificado"),
            ("Criado por:", user.full_name),
            ("Data de Criação:", material.created_at.strftime("%d/%m/%Y %H:%M"))
        ]
        
        for i, (label, value) in enumerate(info_data):
            info_table.cell(i, 0).text = label
            info_table.cell(i, 1).text = value
        
        # Adiciona espaço
        doc.add_paragraph()
        
        # Descrição (se houver)
        if material.description:
            doc.add_heading("Descrição", level=1)
            doc.add_paragraph(material.description)
        
        # Conteúdo principal
        doc.add_heading("Conteúdo", level=1)
        
        # Processa o conteúdo markdown básico
        content_lines = material.content.split('\n')
        for line in content_lines:
            line = line.strip()
            if not line:
                doc.add_paragraph()
            elif line.startswith('# '):
                doc.add_heading(line[2:], level=1)
            elif line.startswith('## '):
                doc.add_heading(line[3:], level=2)
            elif line.startswith('### '):
                doc.add_heading(line[4:], level=3)
            elif line.startswith('**') and line.endswith('**'):
                para = doc.add_paragraph()
                run = para.add_run(line[2:-2])
                run.bold = True
            elif line.startswith('- '):
                doc.add_paragraph(line[2:], style='List Bullet')
            elif line.startswith('1. '):
                doc.add_paragraph(line[3:], style='List Number')
            else:
                doc.add_paragraph(line)
        
        # Rodapé
        footer = doc.sections[0].footer
        footer_para = footer.paragraphs[0]
        footer_para.text = f"Gerado pela plataforma ProfIAs - {datetime.now().strftime('%d/%m/%Y')}"
        
        # Salva o arquivo
        filename = f"material_{material.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
        filepath = self.upload_dir / filename
        doc.save(str(filepath))
        
        return str(filepath)
    
    async def generate_pptx(self, material: Material, user: User) -> str:
        """
        Gera uma apresentação PowerPoint (.pptx) do material.
        
        Cria slides estruturados baseados no conteúdo do material,
        ideal para apresentações em sala de aula.
        """
        # Cria uma nova apresentação
        prs = Presentation()
        
        # Slide de título
        title_slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        title.text = material.title
        subtitle.text = f"{material.subject} - {material.education_level}\nPor: {user.full_name}"
        
        # Slide de informações
        bullet_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(bullet_slide_layout)
        title = slide.shapes.title
        content = slide.placeholders[1]
        
        title.text = "Informações do Material"
        tf = content.text_frame
        tf.text = f"Disciplina: {material.subject or 'Não especificada'}"
        
        p = tf.add_paragraph()
        p.text = f"Nível: {material.education_level or 'Não especificado'}"
        
        p = tf.add_paragraph()
        p.text = f"Duração: {material.estimated_duration or 'Não especificada'} minutos"
        
        if material.description:
            p = tf.add_paragraph()
            p.text = f"Descrição: {material.description}"
        
        # Processa o conteúdo em slides
        content_lines = material.content.split('\n')
        current_slide = None
        current_content = None
        
        for line in content_lines:
            line = line.strip()
            if not line:
                continue
            
            # Novo slide para cada título principal
            if line.startswith('# '):
                slide = prs.slides.add_slide(bullet_slide_layout)
                title = slide.shapes.title
                title.text = line[2:]
                current_content = slide.placeholders[1].text_frame
                current_content.text = ""
                current_slide = slide
            
            # Subtítulos como texto em negrito
            elif line.startswith('## '):
                if current_content:
                    p = current_content.add_paragraph()
                    p.text = line[3:]
                    p.font.bold = True
            
            # Itens de lista
            elif line.startswith('- ') or line.startswith('* '):
                if current_content:
                    p = current_content.add_paragraph()
                    p.text = line[2:]
                    p.level = 1
            
            # Texto normal
            else:
                if current_content:
                    if current_content.text:
                        p = current_content.add_paragraph()
                        p.text = line
                    else:
                        current_content.text = line
        
        # Slide de encerramento
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        title.text = "Obrigado!"
        subtitle.text = f"Material criado com ProfIAs\n{datetime.now().strftime('%d/%m/%Y')}"
        
        # Salva o arquivo
        filename = f"material_{material.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pptx"
        filepath = self.upload_dir / filename
        prs.save(str(filepath))
        
        return str(filepath)
    
    async def generate_pdf(self, material: Material, user: User) -> str:
        """
        Gera um documento PDF do material.
        
        Cria um PDF formatado e otimizado para impressão
        ou distribuição digital.
        """
        filename = f"material_{material.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        filepath = self.upload_dir / filename
        
        # Cria o documento PDF
        doc = SimpleDocTemplate(str(filepath), pagesize=letter)
        styles = getSampleStyleSheet()
        story = []
        
        # Estilo personalizado para título
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=1  # Centralizado
        )
        
        # Título
        story.append(Paragraph(material.title, title_style))
        story.append(Spacer(1, 12))
        
        # Informações do material
        info_style = styles['Normal']
        story.append(Paragraph("<b>Informações do Material</b>", styles['Heading2']))
        story.append(Paragraph(f"<b>Disciplina:</b> {material.subject or 'Não especificada'}", info_style))
        story.append(Paragraph(f"<b>Nível de Ensino:</b> {material.education_level or 'Não especificado'}", info_style))
        story.append(Paragraph(f"<b>Duração Estimada:</b> {material.estimated_duration or 'Não especificada'} minutos", info_style))
        story.append(Paragraph(f"<b>Público-Alvo:</b> {material.target_audience or 'Não especificado'}", info_style))
        story.append(Paragraph(f"<b>Criado por:</b> {user.full_name}", info_style))
        story.append(Paragraph(f"<b>Data de Criação:</b> {material.created_at.strftime('%d/%m/%Y %H:%M')}", info_style))
        story.append(Spacer(1, 20))
        
        # Descrição
        if material.description:
            story.append(Paragraph("<b>Descrição</b>", styles['Heading2']))
            story.append(Paragraph(material.description, styles['Normal']))
            story.append(Spacer(1, 12))
        
        # Conteúdo
        story.append(Paragraph("<b>Conteúdo</b>", styles['Heading2']))
        
        # Processa o conteúdo
        content_lines = material.content.split('\n')
        for line in content_lines:
            line = line.strip()
            if not line:
                story.append(Spacer(1, 6))
            elif line.startswith('# '):
                story.append(Paragraph(line[2:], styles['Heading1']))
            elif line.startswith('## '):
                story.append(Paragraph(line[3:], styles['Heading2']))
            elif line.startswith('### '):
                story.append(Paragraph(line[4:], styles['Heading3']))
            elif line.startswith('**') and line.endswith('**'):
                story.append(Paragraph(f"<b>{line[2:-2]}</b>", styles['Normal']))
            else:
                story.append(Paragraph(line, styles['Normal']))
        
        # Rodapé
        story.append(Spacer(1, 30))
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=8,
            alignment=1
        )
        story.append(Paragraph(f"Gerado pela plataforma ProfIAs - {datetime.now().strftime('%d/%m/%Y')}", footer_style))
        
        # Constrói o PDF
        doc.build(story)
        
        return str(filepath)

# Instância global do gerador
document_generator = DocumentGenerator()

@router.post("/{material_id}/export", response_model=ExportResponse)
async def export_material(
    material_id: int,
    export_request: ExportRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Exporta um material no formato especificado.
    
    Gera um arquivo do material no formato solicitado
    e retorna informações para download.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    if not material.content:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Material não possui conteúdo para exportar"
        )
    
    try:
        # Gera o arquivo no formato solicitado
        if export_request.format == ExportFormat.DOCX:
            filepath = await document_generator.generate_docx(material, current_user)
        elif export_request.format == ExportFormat.PPTX:
            filepath = await document_generator.generate_pptx(material, current_user)
        elif export_request.format == ExportFormat.PDF:
            filepath = await document_generator.generate_pdf(material, current_user)
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Formato de exportação não suportado"
            )
        
        # Atualiza o registro do material com informações de exportação
        exported_formats = json.loads(material.exported_formats or "[]")
        file_paths = json.loads(material.file_paths or "{}")
        
        if export_request.format.value not in exported_formats:
            exported_formats.append(export_request.format.value)
        
        file_paths[export_request.format.value] = filepath
        
        material.exported_formats = json.dumps(exported_formats)
        material.file_paths = json.dumps(file_paths)
        material.updated_at = datetime.utcnow()
        
        await db.commit()
        
        # Retorna informações do arquivo gerado
        file_size = os.path.getsize(filepath)
        filename = os.path.basename(filepath)
        
        return ExportResponse(
            material_id=material_id,
            format=export_request.format,
            filename=filename,
            file_size=file_size,
            download_url=f"/api/export/{material_id}/download/{export_request.format.value}",
            generated_at=datetime.utcnow()
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro na exportação: {str(e)}"
        )

@router.get("/{material_id}/download/{format}")
async def download_exported_file(
    material_id: int,
    format: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Faz download de um arquivo exportado.
    
    Retorna o arquivo gerado para download direto
    pelo navegador do usuário.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Verifica se o arquivo existe
    file_paths = json.loads(material.file_paths or "{}")
    filepath = file_paths.get(format)
    
    if not filepath or not os.path.exists(filepath):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Arquivo não encontrado. Gere a exportação novamente."
        )
    
    # Determina o tipo de conteúdo baseado no formato
    content_types = {
        "pdf": "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    }
    
    media_type = content_types.get(format, "application/octet-stream")
    filename = os.path.basename(filepath)
    
    return FileResponse(
        path=filepath,
        media_type=media_type,
        filename=filename
    )

@router.get("/{material_id}/exports")
async def list_material_exports(
    material_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista todas as exportações disponíveis de um material.
    
    Retorna informações sobre os arquivos já gerados
    e disponíveis para download.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Lista os formatos exportados
    exported_formats = json.loads(material.exported_formats or "[]")
    file_paths = json.loads(material.file_paths or "{}")
    
    exports = []
    for format_name in exported_formats:
        filepath = file_paths.get(format_name)
        if filepath and os.path.exists(filepath):
            file_size = os.path.getsize(filepath)
            file_modified = datetime.fromtimestamp(os.path.getmtime(filepath))
            
            exports.append({
                "format": format_name,
                "filename": os.path.basename(filepath),
                "file_size": file_size,
                "generated_at": file_modified.isoformat(),
                "download_url": f"/api/export/{material_id}/download/{format_name}"
            })
    
    return {"exports": exports}