"""
Roteador para funcionalidades de colaboração entre usuários.

Implementa compartilhamento de materiais, gerenciamento de permissões,
comentários e trabalho colaborativo na plataforma.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional
from datetime import datetime, timedelta

from app.database import get_db
from app.models.user import User
from app.models.material import Material
from app.models.collaboration import Collaboration, Comment, PermissionType, CollaborationStatus
from app.routers.auth import get_current_user
from app.schemas.collaboration import (
    CollaborationCreate, CollaborationResponse, CollaborationUpdate,
    CommentCreate, CommentResponse, ShareRequest, ShareResponse
)

router = APIRouter()

@router.post("/share", response_model=ShareResponse)
async def share_material(
    share_request: ShareRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Compartilha um material com outro usuário.
    
    Cria uma nova colaboração permitindo que outro usuário
    acesse o material com as permissões especificadas.
    """
    # Verifica se o material existe e pertence ao usuário
    material_result = await db.execute(
        select(Material).where(
            and_(
                Material.id == share_request.material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = material_result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado ou você não tem permissão"
        )
    
    # Busca o usuário destinatário pelo email
    user_result = await db.execute(
        select(User).where(User.email == share_request.user_email)
    )
    target_user = user_result.scalar_one_or_none()
    
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Verifica se não está tentando compartilhar consigo mesmo
    if target_user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível compartilhar um material consigo mesmo"
        )
    
    # Verifica se já existe uma colaboração ativa
    existing_collab = await db.execute(
        select(Collaboration).where(
            and_(
                Collaboration.material_id == share_request.material_id,
                Collaboration.user_id == target_user.id,
                Collaboration.status.in_([CollaborationStatus.PENDING, CollaborationStatus.ACTIVE])
            )
        )
    )
    
    if existing_collab.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Material já está compartilhado com este usuário"
        )
    
    # Cria a nova colaboração
    collaboration = Collaboration(
        material_id=share_request.material_id,
        user_id=target_user.id,
        permission_type=share_request.permission_type,
        invited_by=current_user.id,
        invitation_message=share_request.message,
        expires_at=datetime.utcnow() + timedelta(days=share_request.expires_in_days) if share_request.expires_in_days else None
    )
    
    db.add(collaboration)
    await db.commit()
    await db.refresh(collaboration)
    
    return ShareResponse(
        collaboration_id=collaboration.id,
        material_title=material.title,
        shared_with=target_user.email,
        permission_type=collaboration.permission_type,
        status=collaboration.status,
        created_at=collaboration.created_at
    )

@router.get("/shared-with-me", response_model=List[CollaborationResponse])
async def list_shared_materials(
    status_filter: Optional[CollaborationStatus] = Query(None, description="Filtrar por status"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista materiais compartilhados com o usuário atual.
    
    Retorna todos os materiais que outros usuários compartilharam
    com o usuário logado, incluindo informações de permissão.
    """
    query = select(Collaboration, Material, User).join(
        Material, Collaboration.material_id == Material.id
    ).join(
        User, Material.creator_id == User.id
    ).where(
        Collaboration.user_id == current_user.id
    )
    
    if status_filter:
        query = query.where(Collaboration.status == status_filter)
    
    result = await db.execute(query)
    collaborations_data = result.fetchall()
    
    collaborations = []
    for collab, material, owner in collaborations_data:
        collaborations.append(CollaborationResponse(
            id=collab.id,
            material_id=material.id,
            material_title=material.title,
            material_description=material.description,
            owner_name=owner.full_name,
            owner_email=owner.email,
            permission_type=collab.permission_type,
            status=collab.status,
            created_at=collab.created_at,
            last_activity=collab.last_activity
        ))
    
    return collaborations

@router.get("/my-shares", response_model=List[CollaborationResponse])
async def list_my_shares(
    material_id: Optional[int] = Query(None, description="Filtrar por material"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista materiais que o usuário compartilhou com outros.
    
    Mostra todos os compartilhamentos feitos pelo usuário,
    permitindo gerenciar permissões e acompanhar colaborações.
    """
    query = select(Collaboration, Material, User).join(
        Material, Collaboration.material_id == Material.id
    ).join(
        User, Collaboration.user_id == User.id
    ).where(
        Material.creator_id == current_user.id
    )
    
    if material_id:
        query = query.where(Material.id == material_id)
    
    result = await db.execute(query)
    collaborations_data = result.fetchall()
    
    collaborations = []
    for collab, material, collaborator in collaborations_data:
        collaborations.append(CollaborationResponse(
            id=collab.id,
            material_id=material.id,
            material_title=material.title,
            material_description=material.description,
            collaborator_name=collaborator.full_name,
            collaborator_email=collaborator.email,
            permission_type=collab.permission_type,
            status=collab.status,
            created_at=collab.created_at,
            last_activity=collab.last_activity
        ))
    
    return collaborations

@router.put("/{collaboration_id}/accept")
async def accept_collaboration(
    collaboration_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Aceita um convite de colaboração.
    
    Permite que o usuário aceite um convite para colaborar
    em um material compartilhado por outro usuário.
    """
    # Busca a colaboração
    result = await db.execute(
        select(Collaboration).where(
            and_(
                Collaboration.id == collaboration_id,
                Collaboration.user_id == current_user.id,
                Collaboration.status == CollaborationStatus.PENDING
            )
        )
    )
    collaboration = result.scalar_one_or_none()
    
    if not collaboration:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Convite de colaboração não encontrado"
        )
    
    # Verifica se não expirou
    if collaboration.expires_at and collaboration.expires_at < datetime.utcnow():
        collaboration.status = CollaborationStatus.ENDED
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Convite de colaboração expirado"
        )
    
    # Aceita a colaboração
    collaboration.status = CollaborationStatus.ACTIVE
    collaboration.accepted_at = datetime.utcnow()
    collaboration.last_activity = datetime.utcnow()
    
    await db.commit()
    
    return {"message": "Colaboração aceita com sucesso"}

@router.put("/{collaboration_id}/permissions")
async def update_collaboration_permissions(
    collaboration_id: int,
    permission_update: CollaborationUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Atualiza permissões de uma colaboração.
    
    Permite que o dono do material modifique as permissões
    concedidas a um colaborador.
    """
    # Busca a colaboração e verifica se o usuário é o dono do material
    result = await db.execute(
        select(Collaboration, Material).join(
            Material, Collaboration.material_id == Material.id
        ).where(
            and_(
                Collaboration.id == collaboration_id,
                Material.creator_id == current_user.id
            )
        )
    )
    
    collab_data = result.first()
    if not collab_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Colaboração não encontrada ou você não tem permissão"
        )
    
    collaboration, material = collab_data
    
    # Atualiza as permissões
    if permission_update.permission_type:
        collaboration.permission_type = permission_update.permission_type
    
    if permission_update.status:
        collaboration.status = permission_update.status
    
    collaboration.last_activity = datetime.utcnow()
    
    await db.commit()
    
    return {"message": "Permissões atualizadas com sucesso"}

@router.delete("/{collaboration_id}")
async def remove_collaboration(
    collaboration_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Remove uma colaboração.
    
    Permite que o dono do material ou o colaborador
    encerre uma colaboração ativa.
    """
    # Busca a colaboração
    result = await db.execute(
        select(Collaboration, Material).join(
            Material, Collaboration.material_id == Material.id
        ).where(
            and_(
                Collaboration.id == collaboration_id,
                or_(
                    Material.creator_id == current_user.id,  # Dono do material
                    Collaboration.user_id == current_user.id  # Colaborador
                )
            )
        )
    )
    
    collab_data = result.first()
    if not collab_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Colaboração não encontrada"
        )
    
    collaboration, material = collab_data
    
    # Remove a colaboração
    await db.delete(collaboration)
    await db.commit()
    
    return {"message": "Colaboração removida com sucesso"}

@router.post("/{material_id}/comments", response_model=CommentResponse)
async def add_comment(
    material_id: int,
    comment_data: CommentCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Adiciona um comentário a um material.
    
    Permite que colaboradores deixem feedback e sugestões
    em materiais compartilhados.
    """
    # Verifica se o usuário tem acesso ao material
    access_query = select(Material).where(Material.id == material_id)
    
    # Se não é o dono, verifica se tem colaboração ativa
    if not await _user_has_material_access(current_user.id, material_id, db):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Você não tem permissão para comentar neste material"
        )
    
    # Cria o comentário
    comment = Comment(
        material_id=material_id,
        user_id=current_user.id,
        content=comment_data.content,
        parent_comment_id=comment_data.parent_comment_id
    )
    
    db.add(comment)
    await db.commit()
    await db.refresh(comment)
    
    return CommentResponse(
        id=comment.id,
        material_id=comment.material_id,
        user_name=current_user.full_name,
        content=comment.content,
        parent_comment_id=comment.parent_comment_id,
        is_resolved=comment.is_resolved,
        created_at=comment.created_at
    )

@router.get("/{material_id}/comments", response_model=List[CommentResponse])
async def list_comments(
    material_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista comentários de um material.
    
    Retorna todos os comentários feitos em um material,
    organizados hierarquicamente.
    """
    # Verifica acesso ao material
    if not await _user_has_material_access(current_user.id, material_id, db):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Você não tem permissão para ver os comentários deste material"
        )
    
    # Busca os comentários
    result = await db.execute(
        select(Comment, User).join(
            User, Comment.user_id == User.id
        ).where(
            Comment.material_id == material_id
        ).order_by(Comment.created_at)
    )
    
    comments_data = result.fetchall()
    
    comments = []
    for comment, user in comments_data:
        comments.append(CommentResponse(
            id=comment.id,
            material_id=comment.material_id,
            user_name=user.full_name,
            content=comment.content,
            parent_comment_id=comment.parent_comment_id,
            is_resolved=comment.is_resolved,
            created_at=comment.created_at
        ))
    
    return comments

async def _user_has_material_access(user_id: int, material_id: int, db: AsyncSession) -> bool:
    """
    Verifica se um usuário tem acesso a um material.
    
    Retorna True se o usuário é o dono do material ou tem
    uma colaboração ativa com permissões adequadas.
    """
    # Verifica se é o dono
    owner_result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == user_id
            )
        )
    )
    
    if owner_result.scalar_one_or_none():
        return True
    
    # Verifica se tem colaboração ativa
    collab_result = await db.execute(
        select(Collaboration).where(
            and_(
                Collaboration.material_id == material_id,
                Collaboration.user_id == user_id,
                Collaboration.status == CollaborationStatus.ACTIVE
            )
        )
    )
    
    return collab_result.scalar_one_or_none() is not None