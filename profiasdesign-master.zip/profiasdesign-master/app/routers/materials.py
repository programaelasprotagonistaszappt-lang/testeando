"""
Roteador para gerenciamento de materiais pedagógicos.

Implementa CRUD completo para materiais, incluindo organização,
busca, favoritos e gerenciamento de pastas.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, desc
from typing import List, Optional
from datetime import datetime
import json

from app.database import get_db
from app.models.user import User
from app.models.material import Material, MaterialType, MaterialStatus
from app.routers.auth import get_current_user
from app.schemas.material import (
    MaterialCreate, MaterialUpdate, MaterialResponse, 
    MaterialListResponse, FolderCreate
)

router = APIRouter()

@router.post("/", response_model=MaterialResponse)
async def create_material(
    material_data: MaterialCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Cria um novo material pedagógico.
    
    O material é criado como rascunho e pode ser posteriormente
    processado pela IA para gerar o conteúdo final.
    """
    # Cria o novo material
    db_material = Material(
        title=material_data.title,
        description=material_data.description,
        subject=material_data.subject,
        education_level=material_data.education_level,
        target_audience=material_data.target_audience,
        estimated_duration=material_data.estimated_duration,
        material_type=material_data.material_type,
        folder_path=material_data.folder_path,
        tags=json.dumps(material_data.tags) if material_data.tags else None,
        creator_id=current_user.id,
        content="",  # Será preenchido pela IA
        status=MaterialStatus.DRAFT
    )
    
    db.add(db_material)
    await db.commit()
    await db.refresh(db_material)
    
    return db_material

@router.get("/", response_model=List[MaterialListResponse])
async def list_materials(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(50, ge=1, le=100, description="Número máximo de registros"),
    search: Optional[str] = Query(None, description="Termo de busca"),
    subject: Optional[str] = Query(None, description="Filtrar por disciplina"),
    material_type: Optional[MaterialType] = Query(None, description="Filtrar por tipo"),
    folder_path: Optional[str] = Query(None, description="Filtrar por pasta"),
    favorites_only: bool = Query(False, description="Apenas favoritos"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista os materiais do usuário com filtros e paginação.
    
    Permite busca por texto, filtros por categoria e organização
    por pastas, facilitando a localização de materiais específicos.
    """
    # Constrói a query base
    query = select(Material).where(Material.creator_id == current_user.id)
    
    # Aplica filtros
    if search:
        search_filter = or_(
            Material.title.ilike(f"%{search}%"),
            Material.description.ilike(f"%{search}%"),
            Material.content.ilike(f"%{search}%")
        )
        query = query.where(search_filter)
    
    if subject:
        query = query.where(Material.subject == subject)
    
    if material_type:
        query = query.where(Material.material_type == material_type)
    
    if folder_path:
        query = query.where(Material.folder_path.startswith(folder_path))
    
    if favorites_only:
        query = query.where(Material.is_favorite == True)
    
    # Ordena por data de atualização (mais recentes primeiro)
    query = query.order_by(desc(Material.updated_at))
    
    # Aplica paginação
    query = query.offset(skip).limit(limit)
    
    # Executa a query
    result = await db.execute(query)
    materials = result.scalars().all()
    
    return materials

@router.get("/{material_id}", response_model=MaterialResponse)
async def get_material(
    material_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Obtém um material específico pelo ID.
    
    Verifica se o usuário tem permissão para acessar o material
    e atualiza o timestamp de último acesso.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Atualiza o último acesso
    material.last_accessed = datetime.utcnow()
    await db.commit()
    
    return material

@router.put("/{material_id}", response_model=MaterialResponse)
async def update_material(
    material_id: int,
    material_update: MaterialUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Atualiza um material existente.
    
    Permite modificar metadados, conteúdo e organização
    do material, mantendo histórico de modificações.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Atualiza os campos fornecidos
    update_data = material_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        if field == "tags" and value is not None:
            setattr(material, field, json.dumps(value))
        else:
            setattr(material, field, value)
    
    material.updated_at = datetime.utcnow()
    
    await db.commit()
    await db.refresh(material)
    
    return material

@router.delete("/{material_id}")
async def delete_material(
    material_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Remove um material da plataforma.
    
    Exclui permanentemente o material e todos os dados associados.
    Esta ação não pode ser desfeita.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Remove o material
    await db.delete(material)
    await db.commit()
    
    return {"message": "Material removido com sucesso"}

@router.post("/{material_id}/favorite")
async def toggle_favorite(
    material_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Alterna o status de favorito de um material.
    
    Permite que o usuário marque/desmarque materiais
    como favoritos para acesso rápido.
    """
    # Busca o material
    result = await db.execute(
        select(Material).where(
            and_(
                Material.id == material_id,
                Material.creator_id == current_user.id
            )
        )
    )
    material = result.scalar_one_or_none()
    
    if not material:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Material não encontrado"
        )
    
    # Alterna o status de favorito
    material.is_favorite = not material.is_favorite
    await db.commit()
    
    return {
        "message": "Favorito atualizado",
        "is_favorite": material.is_favorite
    }

@router.get("/folders/list")
async def list_folders(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista todas as pastas criadas pelo usuário.
    
    Retorna uma estrutura hierárquica das pastas
    para organização dos materiais.
    """
    # Busca todos os caminhos de pasta únicos
    result = await db.execute(
        select(Material.folder_path).where(
            and_(
                Material.creator_id == current_user.id,
                Material.folder_path.isnot(None)
            )
        ).distinct()
    )
    
    folder_paths = [row[0] for row in result.fetchall()]
    
    # Organiza em estrutura hierárquica
    folders = {}
    for path in folder_paths:
        if path:
            parts = path.split('/')
            current = folders
            for part in parts:
                if part not in current:
                    current[part] = {}
                current = current[part]
    
    return {"folders": folders}

@router.get("/stats/summary")
async def get_user_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Retorna estatísticas resumidas dos materiais do usuário.
    
    Fornece métricas úteis como total de materiais,
    distribuição por tipo, materiais recentes, etc.
    """
    # Total de materiais
    total_result = await db.execute(
        select(Material).where(Material.creator_id == current_user.id)
    )
    total_materials = len(total_result.scalars().all())
    
    # Materiais por tipo
    type_result = await db.execute(
        select(Material.material_type, Material.id).where(
            Material.creator_id == current_user.id
        )
    )
    
    type_counts = {}
    for material_type, _ in type_result.fetchall():
        type_counts[material_type.value] = type_counts.get(material_type.value, 0) + 1
    
    # Materiais favoritos
    favorites_result = await db.execute(
        select(Material).where(
            and_(
                Material.creator_id == current_user.id,
                Material.is_favorite == True
            )
        )
    )
    total_favorites = len(favorites_result.scalars().all())
    
    return {
        "total_materials": total_materials,
        "total_favorites": total_favorites,
        "materials_by_type": type_counts,
        "last_updated": datetime.utcnow().isoformat()
    }