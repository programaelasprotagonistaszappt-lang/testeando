"""
Configuração e gerenciamento do banco de dados.

Este módulo configura a conexão com PostgreSQL usando SQLAlchemy,
define a base para os modelos ORM e fornece funções para inicialização.
"""

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import MetaData
from app.core.config import settings

# Configuração do metadata para convenções de nomenclatura
# Isso garante consistência nos nomes de índices e constraints
metadata = MetaData(naming_convention={
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
})

# Base para todos os modelos ORM
# Todos os modelos da aplicação herdam desta classe
Base = declarative_base(metadata=metadata)

# Engine assíncrono para conexão com o banco
# Configurado para usar pool de conexões para melhor performance
engine = create_async_engine(
    settings.database_url.replace("postgresql://", "postgresql+asyncpg://"),
    echo=settings.debug,  # Log das queries SQL em modo debug
    pool_size=10,  # Número de conexões no pool
    max_overflow=20,  # Conexões extras permitidas
    pool_pre_ping=True,  # Verifica conexões antes de usar
)

# Factory para criar sessões do banco de dados
# Cada requisição usa uma sessão independente
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

async def get_db():
    """
    Dependency que fornece uma sessão de banco de dados para as rotas.
    
    Esta função é usada como dependência do FastAPI para injetar
    uma sessão de banco em cada endpoint que precisa acessar dados.
    
    Yields:
        AsyncSession: Sessão ativa do banco de dados
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            # Em caso de erro, faz rollback da transação
            await session.rollback()
            raise
        finally:
            # Sempre fecha a sessão ao final
            await session.close()

async def init_db():
    """
    Inicializa o banco de dados criando todas as tabelas.
    
    Esta função é chamada na startup da aplicação para garantir
    que todas as tabelas necessárias existam no banco de dados.
    """
    # Importa todos os modelos para garantir que sejam registrados
    from app.models import user, material, ai_interaction, collaboration
    
    async with engine.begin() as conn:
        # Cria todas as tabelas definidas nos modelos
        await conn.run_sync(Base.metadata.create_all)
        
    print("✅ Banco de dados inicializado com sucesso!")