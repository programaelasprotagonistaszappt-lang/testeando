# 🎓 ProfIAs - Plataforma de Geração de Materiais Pedagógicos com IA

<div align="center">
  <img src="./static/img/logo-profias.png" alt="Logo ProfIAs" width="200"/>
  
  **Uma plataforma inovadora que integra Inteligência Artificial ao processo educacional, promovendo o uso ético e colaborativo da tecnologia na criação de materiais didáticos.**
</div>

## 📋 Sobre o Projeto

A **ProfIAs** é uma plataforma pedagógica desenvolvida para auxiliar educadores na criação de materiais didáticos utilizando Inteligência Artificial Generativa (IAGen). O projeto surge como resposta aos desafios contemporâneos da educação, especialmente no contexto pós-pandêmico, onde a necessidade de ferramentas digitais eficazes se tornou evidente.

### 🎯 Objetivos Principais

- **Personalização do Ensino**: Utilizar IA para criar materiais adaptados às necessidades específicas de cada contexto educacional
- **Uso Ético da IA**: Promover o entendimento crítico e responsável da tecnologia
- **Colaboração Docente**: Facilitar o compartilhamento de recursos entre educadores
- **Competências Digitais**: Fortalecer as habilidades tecnológicas dos professores

## 🚀 Funcionalidades

### 📝 Geração de Recursos Pedagógicos
- Criação de planos de aula personalizados
- Geração de exercícios e atividades
- Desenvolvimento de quizzes e avaliações
- Exportação em múltiplos formatos (PDF, DOCX, PPTX)

### 🔐 Sistema de Autenticação
- Login e cadastro seguro para docentes
- Gestão de perfis e preferências
- Controle de acesso baseado em permissões

### ⚖️ Orientações Éticas Obrigatórias
- Alertas sobre uso responsável da IA
- Informações sobre limitações e possíveis "alucinações"
- Reforço do papel crítico do educador

### 📚 Gestão de Histórico
- Registro completo de todas as interações
- Reutilização de prompts bem-sucedidos
- Auditoria e rastreabilidade das ações

### 🗂️ Organização Inteligente
- Sistema de pastas personalizadas
- Tags semânticas para categorização
- Filtros por disciplina e nível de ensino

### 🤝 Colaboração e Compartilhamento
- Compartilhamento de materiais entre docentes
- Controle de permissões (visualização/cópia)
- Biblioteca colaborativa de recursos

### 📖 Base de Conhecimento
- Tutoriais sobre IA na educação
- Guias de melhores práticas
- Documentação sobre vieses e limitações

## 🛠️ Tecnologias Utilizadas

### Backend
- **Python 3.11+**: Linguagem principal
- **FastAPI**: Framework web assíncrono de alta performance
- **SQLAlchemy**: ORM para gestão do banco de dados
- **PostgreSQL**: Banco de dados relacional
- **JWT**: Autenticação segura
- **Docker**: Containerização da aplicação

### Frontend
- **HTML5/CSS3**: Estrutura e estilização
- **JavaScript ES6+**: Interatividade
- **Tailwind CSS**: Framework de estilização
- **Fetch API**: Comunicação com o backend

### Integrações
- **APIs de IA**: OpenAI, Anthropic, Google Gemini, Groq, Cohere
- **Bibliotecas de Exportação**: python-docx, python-pptx, ReportLab

## 📦 Instalação e Configuração

### Pré-requisitos
- Python 3.11 ou superior
- Docker e Docker Compose
- Git

### 1. Clone o Repositório
```bash
git clone https://github.com/seu-usuario/profias-platform.git
cd profias-platform
```

### 2. Configure as Variáveis de Ambiente
```bash
cp .env.example .env
# Edite o arquivo .env com suas chaves de API
```

### 3. Execute com Docker
```bash
docker-compose up -d
```

### 4. Acesse a Plataforma
- Frontend: http://localhost:8000
- API Docs: http://localhost:8000/docs

## 🔧 Configuração Manual (Desenvolvimento)

### 1. Instale as Dependências
```bash
pip install -r requirements.txt
```

### 2. Configure o Banco de Dados
```bash
# Execute as migrações
alembic upgrade head
```

### 3. Inicie o Servidor
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## 📖 Como Usar

### 1. **Primeiro Acesso**
- Acesse a plataforma e crie sua conta
- Complete seu perfil com informações educacionais
- Leia as orientações éticas obrigatórias

### 2. **Gerando Materiais**
- Clique em "Novo Material"
- Defina os parâmetros:
  - Nível de ensino (Infantil ao Superior)
  - Disciplina/tema
  - Perfil do público-alvo
  - Tom de linguagem
  - Duração da atividade
  - Formato de saída
- Revise e aprove o material gerado
- Exporte no formato desejado

### 3. **Organizando Recursos**
- Use pastas para organizar por disciplina
- Adicione tags para facilitar buscas
- Marque materiais favoritos

### 4. **Colaborando**
- Compartilhe materiais com colegas
- Explore a biblioteca colaborativa
- Contribua com avaliações e melhorias

## 🏗️ Arquitetura do Sistema

### Camadas da Aplicação

#### 🔐 **Autenticação e Segurança**
- Controle de acesso seguro
- Gestão de sessões
- Proteção de dados pessoais

#### 🤖 **Orquestração de IA**
- Engenharia de prompts avançada
- Integração com múltiplas APIs de IA
- Processamento assíncrono de requisições

#### 💾 **Persistência de Dados**
- Histórico completo de interações
- Sistema de backup automático
- Auditoria e compliance

#### 📄 **Pipeline de Exportação**
- Conversão para múltiplos formatos
- Processamento de templates
- Otimização de arquivos

## 🔒 Segurança e Privacidade

- **Criptografia**: Dados sensíveis protegidos com AES-256
- **HTTPS**: Comunicação segura obrigatória
- **LGPD**: Conformidade com a Lei Geral de Proteção de Dados
- **Auditoria**: Log completo de todas as ações

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 👥 Equipe

- **Desenvolvimento**: Equipe ProfIAs
- **Orientação Acadêmica**: IFRS Campus Porto Alegre
- **Pesquisa**: Programa de Pós-Graduação

## 📞 Contato

- **Email**: profias@poa.ifrs.edu.br
- **Site**: https://profias.ifrs.edu.br
- **GitHub**: https://github.com/ifrs-poa/profias

---

<div align="center">
  <p><strong>ProfIAs - Transformando a educação através da tecnologia responsável</strong></p>
  <p>Desenvolvido com ❤️ pelo IFRS Campus Porto Alegre</p>
</div>